# PIAssetDatabase

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **str**
**id** | **str**
**name** | **str**
**description** | **str**
**path** | **str**
**extended_properties** | **dict(str, PIValue)**
**links** | **[**PIAssetDatabaseLinks**](../models/PIAssetDatabaseLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
