# PIVersion

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**full_version** | **str**
**major_minor_revision** | **str**
**build** | **str**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
