# PIStreamUpdatesRetrieve

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**source** | **str**
**source_name** | **str**
**source_path** | **str**
**requested_marker** | **str**
**latest_marker** | **str**
**status** | **str**
**events** | **list[PIDataPipeEvent]**
**exception** | **[**PIErrors**](../models/PIErrors.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
