# PIAssetServerLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**databases** | **str**
**notification_contact_templates** | **str**
**security_identities** | **str**
**security_mappings** | **str**
**unit_classes** | **str**
**analysis_rule_plug_ins** | **str**
**time_rule_plug_ins** | **str**
**security** | **str**
**security_entries** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
