# PIAnalysisRule

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **str**
**id** | **str**
**name** | **str**
**description** | **str**
**path** | **str**
**config_string** | **str**
**display_string** | **str**
**editor_type** | **str**
**has_children** | **bool**
**is_configured** | **bool**
**is_initializing** | **bool**
**plug_in_name** | **str**
**supported_behaviors** | **list[str]**
**variable_mapping** | **str**
**links** | **[**PIAnalysisRuleLinks**](../models/PIAnalysisRuleLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
