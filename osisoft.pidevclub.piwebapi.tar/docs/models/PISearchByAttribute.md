# PISearchByAttribute

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**search_root** | **str**
**element_template** | **str**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**
**value_queries** | **list[PIValueQuery]**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
