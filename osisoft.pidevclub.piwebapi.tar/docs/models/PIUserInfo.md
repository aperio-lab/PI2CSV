# PIUserInfo

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**identity_type** | **str**
**name** | **str**
**is_authenticated** | **bool**
**s_i_d** | **str**
**impersonation_level** | **str**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
