# PIAttributeTemplateLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**attribute_templates** | **str**
**element_template** | **str**
**parent** | **str**
**categories** | **str**
**trait** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
