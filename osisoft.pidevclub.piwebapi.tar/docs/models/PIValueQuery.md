# PIValueQuery

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**attribute_name** | **str**
**attribute_u_o_m** | **str**
**attribute_value** | **object**
**search_operator** | **str**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
