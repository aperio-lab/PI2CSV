# PIElementTemplateLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**analysis_templates** | **str**
**attribute_templates** | **str**
**database** | **str**
**categories** | **str**
**base_template** | **str**
**base_templates** | **str**
**derived_templates** | **str**
**default_attribute** | **str**
**notification_rule_templates** | **str**
**security** | **str**
**security_entries** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
